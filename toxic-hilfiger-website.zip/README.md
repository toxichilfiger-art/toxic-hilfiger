# Toxic Hilfiger

Premium streetwear website starter for the Toxic Hilfiger brand.

## Files
- `index.html` — homepage
- `style.css` — styling and responsive layout

Open `index.html` in a browser to preview the site.
